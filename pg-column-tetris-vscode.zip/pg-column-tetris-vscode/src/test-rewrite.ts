/* eslint-disable no-console */
/**
 * Test the rewrite logic in isolation by re-implementing the buildReorderEdit
 * helper without VS Code dependencies, then verifying output SQL parses back
 * to the optimal order.
 */
import { parseCreateTables } from './sqlParser';
import { analyzeTable, resolveColumns } from './analyzer';

function splitTopLevel(body: string): { text: string; offset: number }[] {
  const segments: { text: string; offset: number }[] = [];
  let depth = 0;
  let segStart = 0;
  let i = 0;
  while (i < body.length) {
    const c = body[i];
    if (c === "'") {
      i++;
      while (i < body.length && body[i] !== "'") {
        if (body[i] === '\\') i++;
        i++;
      }
      i++;
      continue;
    }
    if (c === '"') {
      i++;
      while (i < body.length && body[i] !== '"') i++;
      i++;
      continue;
    }
    if (c === '(') depth++;
    else if (c === ')') depth--;
    else if (c === ',' && depth === 0) {
      segments.push({ text: body.slice(segStart, i), offset: segStart });
      segStart = i + 1;
    }
    i++;
  }
  if (segStart < body.length) {
    segments.push({ text: body.slice(segStart), offset: segStart });
  }
  return segments;
}

function rewrite(fullText: string): string {
  const tables = parseCreateTables(fullText);
  if (tables.length === 0) return fullText;
  const table = tables[0];
  const resolved = resolveColumns(table.columns);
  const result = analyzeTable(resolved);
  const optimalRawTexts = result.optimalOrder.map((c) => c.rawText);

  const bodyStart = table.openParenOffset + 1;
  const bodyEnd = table.closeParenOffset;
  const body = fullText.slice(bodyStart, bodyEnd);

  // Indent: detect from first column
  const firstCol = table.columns[0];
  let indent = '    ';
  if (firstCol) {
    const lineStart = fullText.lastIndexOf('\n', firstCol.startOffset - 1) + 1;
    const before = fullText.slice(lineStart, firstCol.startOffset);
    if (/^\s+$/.test(before)) indent = before;
  }

  const allSegments = splitTopLevel(body);
  const colOffsets = new Set(table.columns.map((c) => c.startOffset - bodyStart));
  const constraints: string[] = [];
  for (const seg of allSegments) {
    const leadingWs = seg.text.match(/^\s*/)?.[0].length ?? 0;
    const contentOffset = seg.offset + leadingWs;
    if (!colOffsets.has(contentOffset)) {
      const trimmed = seg.text.trim();
      if (trimmed) constraints.push(trimmed);
    }
  }

  const lines: string[] = [];
  for (const colText of optimalRawTexts) lines.push(indent + colText.trim());
  for (const cText of constraints) lines.push(indent + cText);

  const newBody = '\n' + lines.join(',\n') + '\n';
  return fullText.slice(0, bodyStart) + newBody + fullText.slice(bodyEnd);
}

const cases = [
  {
    name: 'Simple reorder',
    input: `CREATE TABLE users (
    flag BOOLEAN NOT NULL DEFAULT true,
    email VARCHAR(255) NOT NULL,
    id BIGINT PRIMARY KEY,
    age SMALLINT,
    created_at TIMESTAMP NOT NULL,
    bio TEXT
);`,
    expectFirstCol: 'id',
  },
  {
    name: 'With table-level constraints',
    input: `CREATE TABLE orders (
    flag BOOLEAN,
    customer_id BIGINT NOT NULL,
    total NUMERIC(10, 2),
    PRIMARY KEY (customer_id),
    CONSTRAINT chk_total CHECK (total >= 0)
);`,
    expectFirstCol: 'customer_id',
    expectContains: ['PRIMARY KEY (customer_id)', 'CONSTRAINT chk_total'],
  },
  {
    name: 'IF NOT EXISTS + schema',
    input: `CREATE TABLE IF NOT EXISTS public.events (
    is_processed BOOL,
    event_id BIGSERIAL,
    occurred_at TIMESTAMPTZ
);`,
    expectFirstCol: 'event_id',
  },
];

let failed = 0;
for (const c of cases) {
  console.log(`\n--- ${c.name} ---`);
  console.log('INPUT:');
  console.log(c.input);
  const out = rewrite(c.input);
  console.log('OUTPUT:');
  console.log(out);

  // Re-parse and check first col
  const reparsed = parseCreateTables(out);
  const firstCol = reparsed[0]?.columns[0]?.name;
  if (firstCol !== c.expectFirstCol) {
    console.error(`FAIL: expected first col=${c.expectFirstCol}, got ${firstCol}`);
    failed++;
    continue;
  }
  if (c.expectContains) {
    for (const needle of c.expectContains) {
      if (!out.includes(needle)) {
        console.error(`FAIL: expected output to contain "${needle}"`);
        failed++;
      }
    }
  }
  console.log('OK');
}

console.log(`\n${failed === 0 ? 'all rewrite tests passed' : failed + ' rewrite tests failed'}`);
if (failed > 0) process.exit(1);
